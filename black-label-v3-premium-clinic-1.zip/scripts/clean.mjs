import { rm } from 'node:fs/promises';
await Promise.all(['.next','out','build','coverage'].map((path) => rm(path, { recursive: true, force: true })));
