import { defineConfig, globalIgnores } from 'eslint/config';
import nextCoreWebVitals from 'eslint-config-next/core-web-vitals';
import nextTypeScript from 'eslint-config-next/typescript';
import prettier from 'eslint-config-prettier';
export default defineConfig([...nextCoreWebVitals, ...nextTypeScript, prettier, { rules: { 'no-console': ['warn', { allow: ['warn', 'error'] }], '@next/next/no-img-element': 'off' } }, globalIgnores(['.next/**','out/**','build/**','coverage/**','node_modules/**','next-env.d.ts'])]);
