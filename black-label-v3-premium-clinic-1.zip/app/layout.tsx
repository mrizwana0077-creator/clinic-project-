import type * as React from 'react';
import type { Metadata, Viewport } from 'next';
import './globals.css';

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL ?? 'http://localhost:3000';

export const metadata: Metadata = { metadataBase: new URL(siteUrl), title: { default: 'Aurea Skin & Hair Clinic Demo', template: '%s | Aurea Clinic' }, description: 'Premium demo homepage and core pages for a modern skin and hair clinic.', openGraph: { title: 'Aurea Skin & Hair Clinic Demo', description: 'Premium demo website for doctor-led skin, hair and aesthetic care.', url: siteUrl, siteName: 'Aurea Clinic Demo', type: 'website' }, robots: { index: false, follow: false } };
export const viewport: Viewport = { width: 'device-width', initialScale: 1, colorScheme: 'light', themeColor: '#ffffff' };

const clinicSchema = { '@context': 'https://schema.org', '@type': 'MedicalClinic', name: 'Aurea Skin & Hair Clinic Demo', url: siteUrl, telephone: '+91 99999 99999', address: { '@type': 'PostalAddress', streetAddress: 'MG Road', addressLocality: 'Kochi', addressRegion: 'Kerala', addressCountry: 'IN' }, medicalSpecialty: ['Dermatology', 'Hair restoration', 'Aesthetic medicine'] };

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { return <html lang="en"><body className="min-h-screen bg-background font-sans text-foreground antialiased"><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(clinicSchema) }} />{children}</body></html>; }
