import type { Config } from 'tailwindcss';
const config: Config = { content: ['./app/**/*.{js,ts,jsx,tsx,mdx}','./components/**/*.{js,ts,jsx,tsx,mdx}','./content/**/*.{js,ts,jsx,tsx,mdx}','./lib/**/*.{js,ts,jsx,tsx,mdx}','./styles/**/*.{css,ts}'], theme: { screens: { xs: '23.4375rem', sm: '40rem', md: '48rem', lg: '64rem', xl: '80rem', '2xl': '96rem' }, extend: {} } };
export default config;
