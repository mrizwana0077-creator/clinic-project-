export const navigationConfig = [
  { label: 'Home', href: '/' }, { label: 'About', href: '/about' }, { label: 'Services', href: '/services' }, { label: 'Doctors', href: '/doctors' }, { label: 'Gallery', href: '/gallery' }, { label: 'Contact', href: '/contact' }
] as const;
