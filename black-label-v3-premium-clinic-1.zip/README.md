# Aurea Clinic Demo — Black Label Premium Transformation

Premium agency-style demo website for a modern skin and hair clinic.

## Scope

Refined existing pages only:

- Homepage
- About
- Services
- Service detail template
- Contact
- Appointment
- Custom 404

No blog, dashboard, CMS, API, backend, database, payment or authentication was added.

## Quality Focus

- premium visual rhythm
- improved medical copywriting
- stronger trust and consultation reassurance
- polished CTAs and micro-interactions
- refined responsive layouts
- accessibility and SEO improvements
- lightweight local assets

## Commands

```bash
npm install
npm run dev
npm run verify
```
