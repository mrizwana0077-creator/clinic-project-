import type * as React from 'react';
import { cn } from '@/lib/utils/cn';
export type BadgeVariant = 'primary'|'accent'|'neutral'|'success'|'warning'|'error';
export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> { variant?: BadgeVariant; }
const styles: Record<BadgeVariant,string> = { primary:'bg-primary-50 text-primary-800 ring-primary-100', accent:'bg-accent-50 text-accent-800 ring-accent-100', neutral:'bg-neutral-100 text-neutral-700 ring-neutral-200', success:'bg-accent-50 text-success ring-accent-100', warning:'bg-neutral-100 text-warning ring-neutral-200', error:'bg-neutral-100 text-error ring-neutral-200' };
/** Non-interactive status or proof label. */
export function Badge({ variant='neutral', className, ...props }: BadgeProps) { return <span className={cn('inline-flex items-center rounded-full px-2.5 py-1 text-xs font-semibold ring-1 ring-inset', styles[variant], className)} {...props}/>; }
