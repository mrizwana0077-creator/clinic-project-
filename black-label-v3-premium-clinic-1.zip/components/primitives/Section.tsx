import type * as React from 'react';
import { cn } from '@/lib/utils/cn';
export type SectionSpacing = 'none'|'default'|'large';
export type SectionSurface = 'base'|'muted'|'primary'|'accent';
export interface SectionProps extends React.HTMLAttributes<HTMLElement> { spacing?: SectionSpacing; surface?: SectionSurface; }
const spacingClasses: Record<SectionSpacing,string> = { none:'', default:'section-padding', large:'section-padding-lg' };
const surfaceClasses: Record<SectionSurface,string> = { base:'bg-background text-foreground', muted:'bg-background-muted text-foreground', primary:'bg-primary-950 text-neutral-0', accent:'bg-accent-50 text-foreground' };
/** Semantic page section primitive. */
export function Section({ spacing='default', surface='base', className, ...props }: SectionProps) { return <section className={cn(spacingClasses[spacing], surfaceClasses[surface], className)} {...props}/>; }
