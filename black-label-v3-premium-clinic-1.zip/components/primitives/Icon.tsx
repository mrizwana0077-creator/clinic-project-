import type * as React from 'react';
import { cn } from '@/lib/utils/cn';
export type IconWrapperSize = 'sm'|'md'|'lg';
export interface IconWrapperProps extends React.HTMLAttributes<HTMLSpanElement> { size?: IconWrapperSize; decorative?: boolean; }
const sizes: Record<IconWrapperSize,string> = { sm:'size-4', md:'size-5', lg:'size-6' };
/** Consistent wrapper for SVG/icons. */
export function IconWrapper({ size='md', decorative=true, className, children, ...props }: IconWrapperProps) { return <span aria-hidden={decorative || undefined} className={cn('inline-flex shrink-0 items-center justify-center text-current', sizes[size], className)} {...props}>{children}</span>; }
export { IconWrapper as Icon };
