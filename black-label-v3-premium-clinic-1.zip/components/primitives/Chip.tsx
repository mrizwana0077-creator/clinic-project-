import type * as React from 'react';
import { cn } from '@/lib/utils/cn';
export interface ChipProps extends React.ButtonHTMLAttributes<HTMLButtonElement> { selected?: boolean; }
/** Compact interactive selection primitive. */
export function Chip({ selected=false, className, children, type='button', ...props }: ChipProps) { return <button type={type} aria-pressed={selected} className={cn('inline-flex min-h-10 items-center justify-center rounded-full border px-4 py-2 text-sm font-medium transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring disabled:opacity-50', selected ? 'border-primary-700 bg-primary-700 text-neutral-0' : 'border-border bg-surface text-foreground-muted hover:bg-primary-50 hover:text-primary-800', className)} {...props}>{children}</button>; }
