import type * as React from 'react';
import { cn } from '@/lib/utils/cn';
export type SkeletonVariant = 'text'|'card'|'avatar'|'image'|'rectangle';
export interface SkeletonProps extends React.HTMLAttributes<HTMLDivElement> { variant?: SkeletonVariant; label?: string; }
const styles: Record<SkeletonVariant,string> = { text:'h-4 w-full rounded-xs', card:'h-48 w-full rounded-xl', avatar:'size-12 rounded-full', image:'aspect-video w-full rounded-xl', rectangle:'h-24 w-full rounded-md' };
/** Loading placeholder that preserves layout shape. */
export function Skeleton({ variant='rectangle', label, className, ...props }: SkeletonProps) { return <div role={label ? 'status' : undefined} aria-label={label} aria-hidden={label ? undefined : true} className={cn('animate-pulse bg-neutral-200', styles[variant], className)} {...props}/>; }
