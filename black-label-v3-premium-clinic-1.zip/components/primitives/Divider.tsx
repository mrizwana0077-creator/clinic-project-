import type * as React from 'react';
import { cn } from '@/lib/utils/cn';
export interface DividerProps extends React.HTMLAttributes<HTMLHRElement> { orientation?: 'horizontal'|'vertical'; }
/** Decorative divider for subtle separation. */
export function Divider({ orientation='horizontal', className, ...props }: DividerProps) { return <hr aria-orientation={orientation} className={cn('border-0 bg-border', orientation === 'horizontal' ? 'h-px w-full' : 'h-full min-h-6 w-px', className)} {...props}/>; }
