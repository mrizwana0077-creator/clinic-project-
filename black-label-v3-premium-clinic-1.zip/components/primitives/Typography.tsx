import type * as React from 'react';
import { cn } from '@/lib/utils/cn';
type Element = keyof React.JSX.IntrinsicElements;
export type TypographyVariant = 'display'|'h1'|'h2'|'h3'|'h4'|'body-lg'|'body'|'small'|'caption'|'label';
export interface TypographyProps extends React.HTMLAttributes<HTMLElement> { variant?: TypographyVariant; as?: Element; }
const element: Record<TypographyVariant,Element> = { display:'p', h1:'h1', h2:'h2', h3:'h3', h4:'h4', 'body-lg':'p', body:'p', small:'p', caption:'span', label:'span' };
const styles: Record<TypographyVariant,string> = { display:'text-5xl md:text-6xl lg:text-7xl font-bold tracking-[-0.055em] leading-[0.96] text-foreground', h1:'text-4xl md:text-5xl lg:text-6xl font-bold tracking-[-0.045em] leading-[1.02] text-foreground', h2:'text-3xl md:text-4xl lg:text-5xl font-bold tracking-[-0.04em] leading-[1.07] text-foreground', h3:'text-2xl md:text-3xl font-bold tracking-[-0.03em] leading-tight text-foreground', h4:'text-xl font-semibold tracking-[-0.02em] text-foreground', 'body-lg':'text-lg md:text-xl leading-8 text-foreground-muted', body:'text-base leading-7 text-foreground-muted', small:'text-sm leading-6 text-foreground-muted', caption:'text-xs leading-5 text-foreground-muted', label:'text-sm font-semibold text-foreground' };
/** Semantic typography primitive for custom-grade hierarchy without one-off styling. */
export function Typography({ variant='body', as, className, ...props }: TypographyProps) { const Component = as ?? element[variant]; return <Component className={cn(styles[variant], className)} {...props} />; }
