import type * as React from 'react';
import { cn } from '@/lib/utils/cn';
export type SpinnerSize = 'sm' | 'md' | 'lg';
export interface SpinnerProps extends React.HTMLAttributes<HTMLSpanElement> { size?: SpinnerSize; label?: string; }
const sizes: Record<SpinnerSize,string> = { sm: 'size-4 border-2', md: 'size-5 border-2', lg: 'size-8 border-4' };
/** Lightweight loading indicator. */
export function Spinner({ size='md', label='Loading', className, ...props }: SpinnerProps) { return <span role="status" aria-label={label} className={cn('inline-block animate-spin rounded-full border-neutral-200 border-t-primary-700', sizes[size], className)} {...props} />; }
