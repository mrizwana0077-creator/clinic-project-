import type * as React from 'react';
import { cn } from '@/lib/utils/cn';
export type AvatarSize = 'sm'|'md'|'lg';
export interface AvatarProps extends React.HTMLAttributes<HTMLDivElement> { src?: string; alt?: string; fallback?: string; size?: AvatarSize; }
const sizes: Record<AvatarSize,string> = { sm:'size-8 text-xs', md:'size-12 text-sm', lg:'size-16 text-base' };
/** Profile image/fallback primitive. */
export function Avatar({ src, alt='', fallback='?', size='md', className, ...props }: AvatarProps) { return <div className={cn('inline-flex shrink-0 items-center justify-center overflow-hidden rounded-full bg-primary-50 font-semibold text-primary-800 ring-1 ring-border', sizes[size], className)} {...props}>{src ? <img src={src} alt={alt} className="size-full object-cover" loading="lazy"/> : <span>{fallback}</span>}</div>; }
