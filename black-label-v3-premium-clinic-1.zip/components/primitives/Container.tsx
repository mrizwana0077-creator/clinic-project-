import type * as React from 'react';
import { cn } from '@/lib/utils/cn';
export type ContainerSize = 'narrow'|'default'|'wide'|'full';
export interface ContainerProps extends React.HTMLAttributes<HTMLDivElement> { size?: ContainerSize; }
const sizes: Record<ContainerSize,string> = { narrow:'container-narrow', default:'container-default', wide:'container-wide', full:'w-full' };
/** Width-constrained layout primitive. */
export function Container({ size='default', className, ...props }: ContainerProps) { return <div className={cn(sizes[size], className)} {...props}/>; }
