import type * as React from 'react';
/** Main page wrapper for future pages. */
export function PageWrapper({ children }: Readonly<{ children: React.ReactNode }>) { return <main id="main-content">{children}</main>; }
