import { Typography } from '@/components/primitives';
/** Minimal premium logo lockup for demo clinic shell. */
export function Logo() { return <a href="/" className="flex items-center gap-3 rounded-md focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring"><span className="grid size-10 place-items-center rounded-full bg-primary-950 text-sm font-bold text-neutral-0">A</span><span><Typography variant="label" className="block text-primary-950">Aurea Clinic</Typography><span className="block text-xs text-foreground-muted">Skin & Hair</span></span></a>; }
