'use client';
import type * as React from 'react';
import { motion, useReducedMotion } from 'framer-motion';
/** Subtle premium reveal wrapper; static for users who prefer reduced motion. */
export function HomeReveal({ children, className, delay = 0 }: Readonly<{ children: React.ReactNode; className?: string; delay?: number }>) { const reduceMotion = useReducedMotion(); if (reduceMotion) return <div className={className}>{children}</div>; return <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: '-72px' }} transition={{ duration: 0.58, delay, ease: [0.16, 1, 0.3, 1] }} className={className}>{children}</motion.div>; }
