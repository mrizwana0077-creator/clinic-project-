import type { NextConfig } from 'next';
const nextConfig: NextConfig = { reactStrictMode: true, poweredByHeader: false, compress: true, typedRoutes: true, images: { formats: ['image/avif', 'image/webp'], minimumCacheTTL: 31536000, remotePatterns: [] }, experimental: { optimizePackageImports: ['framer-motion'] } };
export default nextConfig;
